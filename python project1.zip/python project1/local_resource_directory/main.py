"""Launch the Local Resource Directory terminal application."""
from src.business_logic import ResourceService
from src.storage import ResourceStorage
from src.ui import run_cli


def main() -> None:
    """Initialize persistence and start the CLI."""
    storage = ResourceStorage("data")
    service = ResourceService(storage)
    run_cli(service)


if __name__ == "__main__":
    main()
