# API Reference

## Shared architecture

Both entry points use `ResourceService` from `src.business_logic`. The CLI starts with
`python main.py`; the optional web interface starts with `streamlit run app_streamlit.py`.
The backend modules use the Python standard library only.

## `src.models`

- `Resource`: immutable dataclass representing one directory record.
- `ServiceCategory`, `ServiceStatus`: allowed category and lifecycle enums.
- `Resource.to_dict()` and `Resource.from_dict(mapping)`: serialization helpers.

## `src.validators`

- `validate_resource_data(mapping) -> dict[str, str]`: validates all record fields,
  including required text, identifier pattern, category/status membership, phone and email.
- `validate_id(value)`, `validate_phone(value)`, `validate_email(value)`.
- `prompt_value(prompt, validator, input_fn=input)`: repeats on invalid input.
- `prompt_int(prompt, minimum, maximum, input_fn=input)`: bounded integer prompt.

Raises `ValidationError` (a `ValueError`) for invalid fields.

## `src.storage`

`ResourceStorage(data_dir="data")` manages canonical JSON and CSV snapshots, an SQLite
mirror, OS-level advisory locks, thread locking, atomic replacement, and the audit log.

- `list_resources() -> list[Resource]`
- `save_all(resources) -> None`
- `search_index(query="", category="", status="") -> list[Resource]`
- `index_info() -> list[str]`
- `log(action, detail="") -> None`

SQLite indexes: category, case-insensitive name, and status. JSON is canonical; SQLite is
rebuildable. A malformed JSON file is archived as `resources.corrupt_<timestamp>.bak`.

## `src.business_logic`

`ResourceService(storage)` is the application facade shared by both UIs.

- `all()`, `search(query="", category="", status="")`
- `add(data) -> Resource`: validates and rejects duplicate IDs.
- `update(resource_id, data) -> Resource`
- `delete(resource_id) -> bool`
- `summary() -> dict`: total, category/status counts, contact completeness.

## `src.importer`

`import_csv(path, service) -> dict` imports valid rows and returns `imported` and
row-numbered `errors`. A bad row does not stop later rows from being checked.

## `src.exporters`

- `export_markdown(service, path) -> Path`
- `export_csv(service, path) -> Path`
- `export_audit(service, path) -> Path`

All exports create parent directories where needed and append an audit event.

## Persistence and concurrency notes

Writes use a same-directory temporary file, flush/fsync, then `os.replace`. A
`threading.RLock` protects in-process access; `fcntl` (POSIX) or `msvcrt` (Windows)
provides advisory process locking. SQLite uses WAL and parameterized SQL.
