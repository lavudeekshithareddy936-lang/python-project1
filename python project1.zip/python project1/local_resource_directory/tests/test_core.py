"""Automated tests for validation, persistence recovery, indexing and core operations."""
import json
import tempfile
import unittest
from pathlib import Path
from src.business_logic import ResourceService
from src.models import Resource
from src.storage import ResourceStorage
from src.validators import ValidationError, validate_resource_data

SAMPLE = {
    "resource_id": "TEST-01", "name": "Test Resource", "category": "Community",
    "description": "A test resource.", "address": "Test address",
    "phone": "+91 00000 00000", "email": "test@example.org", "website": "",
    "hours": "Weekdays", "eligibility": "Open to all", "cost": "Free", "status": "Active"
}


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.storage = ResourceStorage(self.temp.name)
        self.service = ResourceService(self.storage)

    def tearDown(self):
        self.temp.cleanup()

    def test_required_field_rejects_blank(self):
        data = dict(SAMPLE, name="  ")
        with self.assertRaises(ValidationError):
            validate_resource_data(data)

    def test_numeric_phone_rejected(self):
        data = dict(SAMPLE, phone="call-me")
        with self.assertRaises(ValidationError):
            validate_resource_data(data)

    def test_add_search_and_summary(self):
        self.service.add(SAMPLE)
        self.assertEqual(len(self.service.search("Test")), 1)
        self.assertEqual(self.service.summary()["total"], 1)

    def test_duplicate_id_rejected(self):
        self.service.add(SAMPLE)
        with self.assertRaises(ValueError):
            self.service.add(SAMPLE)

    def test_delete(self):
        self.service.add(SAMPLE)
        self.assertTrue(self.service.delete("TEST-01"))
        self.assertFalse(self.service.delete("missing"))

    def test_corrupt_json_is_archived_and_recovered(self):
        self.storage.json_path.write_text("{broken", encoding="utf-8")
        recovered = ResourceStorage(self.temp.name)
        self.assertEqual(recovered.list_resources(), [])
        self.assertTrue(list(Path(self.temp.name).glob("resources.corrupt_*.bak")))

    def test_sqlite_indexes_exist(self):
        names = self.storage.index_info()
        self.assertIn("idx_resources_category", names)
        self.assertIn("idx_resources_name", names)
        self.assertIn("idx_resources_status", names)

    def test_boundary_lengths(self):
        data = dict(SAMPLE, name="N" * 120)
        self.assertEqual(validate_resource_data(data)["name"], "N" * 120)
        with self.assertRaises(ValidationError):
            validate_resource_data(dict(SAMPLE, name="N" * 121))

    def test_save_and_reload(self):
        self.service.add(SAMPLE)
        self.assertEqual(self.storage.list_resources()[0].resource_id, "TEST-01")


if __name__ == "__main__":
    unittest.main()
