"""Native Streamlit interface backed by the same src service as the CLI."""
from pathlib import Path
import streamlit as st
from src.business_logic import ResourceService
from src.exporters import export_csv, export_markdown
from src.importer import import_csv
from src.models import Resource, ServiceCategory, ServiceStatus
from src.storage import ResourceStorage

st.set_page_config(page_title="Local Resource Directory", page_icon="🧭", layout="wide")
st.title("🧭 Local Resource Directory")
st.caption("Find, maintain, and report on community services.")

@st.cache_resource
def get_service() -> ResourceService:
    return ResourceService(ResourceStorage("data"))

service = get_service()
tab_search, tab_add, tab_reports, tab_import = st.tabs(["Search directory", "Add resource", "Reports", "CSV import"])

with tab_search:
    left, right = st.columns([2, 1])
    with left:
        query = st.text_input("Keyword", placeholder="Name, service, or address")
    with right:
        category = st.selectbox("Category", ["Any"] + [item.value for item in ServiceCategory])
    status = st.selectbox("Status", ["Any"] + [item.value for item in ServiceStatus])
    results = service.search(query, "" if category == "Any" else category, "" if status == "Any" else status)
    st.write(f"{len(results)} result(s)")
    if results:
        st.dataframe([item.to_dict() for item in results], use_container_width=True, hide_index=True)
    else:
        st.info("No matching resources.")

with tab_add:
    with st.form("add_resource", clear_on_submit=True):
        a, b = st.columns(2)
        with a:
            rid = st.text_input("Resource ID", placeholder="e.g. HYD-046")
            name = st.text_input("Service name")
            cat = st.selectbox("Category", [item.value for item in ServiceCategory])
            address = st.text_input("Address")
            phone = st.text_input("Phone")
            email = st.text_input("Email")
        with b:
            description = st.text_area("Description")
            website = st.text_input("Website")
            hours = st.text_input("Hours")
            eligibility = st.text_input("Eligibility")
            cost = st.text_input("Cost")
            state = st.selectbox("Status", [item.value for item in ServiceStatus])
        submitted = st.form_submit_button("Add resource")
    if submitted:
        try:
            service.add({"resource_id": rid, "name": name, "category": cat, "description": description,
                         "address": address, "phone": phone, "email": email, "website": website,
                         "hours": hours, "eligibility": eligibility, "cost": cost, "status": state})
            st.success("Resource added.")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

with tab_reports:
    metrics = service.summary()
    c1, c2, c3 = st.columns(3)
    c1.metric("Total resources", metrics["total"])
    c2.metric("Contact completeness", f'{metrics["contact_completeness_percent"]}%')
    c3.metric("Active resources", metrics["by_status"].get("Active", 0))
    st.subheader("By category")
    st.bar_chart(metrics["by_category"])
    st.subheader("By status")
    st.dataframe([{"Status": key, "Count": value} for key, value in metrics["by_status"].items()],
                 use_container_width=True, hide_index=True)
    if st.button("Generate report files"):
        export_markdown(service, "reports/summary.md")
        export_csv(service, "reports/resources.csv")
        st.success("Reports saved in the reports/ folder.")

with tab_import:
    uploaded = st.file_uploader("Upload a directory CSV", type=["csv"])
    if uploaded is not None and st.button("Import valid rows"):
        import_path = Path("data") / "streamlit_upload.csv"
        import_path.write_bytes(uploaded.getvalue())
        result = import_csv(import_path, service)
        st.success(f"Imported {result['imported']} row(s); rejected {len(result['errors'])}.")
        if result["errors"]:
            st.dataframe(result["errors"], use_container_width=True, hide_index=True)
