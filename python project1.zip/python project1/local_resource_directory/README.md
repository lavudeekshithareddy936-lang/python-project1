# Local Resource Directory

A beginner-friendly Python mini-project for searching and maintaining community service records.

## Features

- Menu-driven ANSI terminal UI with paginated results.
- Native Streamlit web UI using the same `src/` backend.
- Defensive validation, JSON/CSV persistence, SQLite mirror and indexes.
- Atomic snapshots, thread/process locking, corrupted-JSON recovery, and timestamped audit log.
- CSV bulk import with per-row errors; Markdown, CSV, and audit exports.
- 40-record starter dataset, unittest suite, GitHub Actions CI, and API reference.

## Requirements

- Python 3.10+
- Streamlit only for the web UI (`pip install -r requirements.txt`)
- No third-party packages are needed for the core CLI/backend.

## Run the Terminal CLI

From the project root:

```bash
python main.py
```

Use menu options to list, search/filter, add records, view summary metrics, and export reports.
Use `NO_COLOR=1 python main.py` to disable ANSI colors.

## Run the Streamlit Web UI

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app_streamlit.py
```

Streamlit opens the app in your browser. Search, add records, review metrics, and import CSV
from the tabs. The UI uses native Streamlit components; styling is in `.streamlit/config.toml`.

## Tests

```bash
python -m unittest discover -s tests -v
```

## Data and outputs

- `data/resources.json`: canonical data store.
- `data/resources.csv`: portable snapshot.
- `data/resources.sqlite3`: indexed query mirror, rebuilt from JSON on startup.
- `data/audit_log.txt`: timestamped action log.
- `reports/`: generated exports.

The seed file contains 40 illustrative sample records. Some entries are intentionally marked
`Needs review` or `Closed` to exercise filtering and boundary/edge-case handling. Contact details
are illustrative and should be verified before real-world use.
