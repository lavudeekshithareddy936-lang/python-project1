"""Defensive validation helpers and crash-resistant terminal prompts."""
import re
from typing import Callable, TypeVar

T = TypeVar("T")
_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{1,31}$")
_PHONE_RE = re.compile(r"^[0-9+(). -]{7,25}$")
_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


class ValidationError(ValueError):
    """Raised when user-provided data does not meet a field rule."""


def required_text(value: object, field: str, max_length: int = 250) -> str:
    """Validate and normalize a required text value."""
    if not isinstance(value, str):
        raise ValidationError(f"{field} must be text.")
    value = value.strip()
    if not value:
        raise ValidationError(f"{field} cannot be blank.")
    if len(value) > max_length:
        raise ValidationError(f"{field} must be {max_length} characters or fewer.")
    return value


def optional_text(value: object, field: str, max_length: int = 500) -> str:
    """Validate optional text."""
    if value is None:
        return ""
    if not isinstance(value, str) or len(value.strip()) > max_length:
        raise ValidationError(f"{field} must be text of at most {max_length} characters.")
    return value.strip()


def validate_id(value: object) -> str:
    """Validate a stable record identifier."""
    result = required_text(value, "ID", 32)
    if not _ID_RE.fullmatch(result):
        raise ValidationError("ID must use 2–32 letters, digits, underscores, or hyphens.")
    return result


def validate_phone(value: object) -> str:
    """Validate a phone number while permitting common punctuation."""
    result = optional_text(value, "Phone", 25)
    if result and not _PHONE_RE.fullmatch(result):
        raise ValidationError("Phone contains unsupported characters or has an invalid length.")
    return result


def validate_email(value: object) -> str:
    """Validate an optional email address."""
    result = optional_text(value, "Email", 254)
    if result and not _EMAIL_RE.fullmatch(result):
        raise ValidationError("Email address is not in a valid format.")
    return result


def validate_resource_data(data: dict[str, object]) -> dict[str, str]:
    """Validate fields for a resource record."""
    from .models import ServiceCategory, ServiceStatus
    allowed_categories = {item.value for item in ServiceCategory}
    allowed_statuses = {item.value for item in ServiceStatus}
    result = {
        "resource_id": validate_id(data.get("resource_id", "")),
        "name": required_text(data.get("name", ""), "Name", 120),
        "category": required_text(data.get("category", ""), "Category", 40),
        "description": required_text(data.get("description", ""), "Description", 1000),
        "address": required_text(data.get("address", ""), "Address", 250),
        "phone": validate_phone(data.get("phone", "")),
        "email": validate_email(data.get("email", "")),
        "website": optional_text(data.get("website", ""), "Website", 250),
        "hours": optional_text(data.get("hours", ""), "Hours", 150),
        "eligibility": optional_text(data.get("eligibility", ""), "Eligibility", 300),
        "cost": optional_text(data.get("cost", ""), "Cost", 150),
        "status": required_text(data.get("status", "Active"), "Status", 30),
        "updated_at": optional_text(data.get("updated_at", ""), "Updated at", 40),
    }
    if result["category"] not in allowed_categories:
        raise ValidationError("Category must be one of: " + ", ".join(sorted(allowed_categories)))
    if result["status"] not in allowed_statuses:
        raise ValidationError("Status must be one of: " + ", ".join(sorted(allowed_statuses)))
    return result


def prompt_value(prompt: str, validator: Callable[[str], T], input_fn: Callable[[str], str] = input) -> T:
    """Repeat a prompt until its validator accepts the value."""
    while True:
        try:
            return validator(input_fn(prompt))
        except (ValidationError, ValueError, TypeError) as exc:
            print(f"  Invalid input: {exc}. Please try again.")
        except (EOFError, KeyboardInterrupt):
            print("\nInput cancelled.")
            raise


def prompt_int(prompt: str, minimum: int, maximum: int,
               input_fn: Callable[[str], str] = input) -> int:
    """Prompt for an integer within inclusive bounds."""
    def check(raw: str) -> int:
        raw = raw.strip()
        if not raw:
            raise ValidationError("a value is required")
        try:
            value = int(raw)
        except ValueError as exc:
            raise ValidationError("enter a whole number") from exc
        if not minimum <= value <= maximum:
            raise ValidationError(f"enter a number from {minimum} to {maximum}")
        return value
    return prompt_value(prompt, check, input_fn)
