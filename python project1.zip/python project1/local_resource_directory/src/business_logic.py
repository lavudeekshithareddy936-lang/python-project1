"""Application operations for resources, queries and summary metrics."""
from collections import Counter
from datetime import datetime, timezone
from typing import Any
from .models import Resource
from .storage import ResourceStorage
from .validators import validate_resource_data


class ResourceService:
    """Business layer shared by CLI and Streamlit."""

    def __init__(self, storage: ResourceStorage) -> None:
        self.storage = storage

    def all(self) -> list[Resource]:
        return self.storage.list_resources()

    def search(self, query: str = "", category: str = "", status: str = "") -> list[Resource]:
        return self.storage.search_index(query, category, status)

    def add(self, data: dict[str, object]) -> Resource:
        """Validate, add, and persist one new resource."""
        clean = validate_resource_data(data)
        if any(item.resource_id == clean["resource_id"] for item in self.all()):
            raise ValueError(f"Resource ID {clean['resource_id']} already exists.")
        clean["updated_at"] = clean["updated_at"] or datetime.now(timezone.utc).isoformat(timespec="seconds")
        resource = Resource.from_dict(clean)
        self.storage.save_all(self.all() + [resource])
        self.storage.log("ADD", f"{resource.resource_id}: {resource.name}")
        return resource

    def update(self, resource_id: str, data: dict[str, object]) -> Resource:
        """Replace an existing record by ID."""
        clean = validate_resource_data({**data, "resource_id": resource_id})
        clean["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        updated = Resource.from_dict(clean)
        items = self.all()
        if not any(item.resource_id == resource_id for item in items):
            raise ValueError(f"Resource ID {resource_id} was not found.")
        self.storage.save_all([updated if item.resource_id == resource_id else item for item in items])
        self.storage.log("UPDATE", f"{resource_id}: {updated.name}")
        return updated

    def delete(self, resource_id: str) -> bool:
        """Delete a resource; return whether a record was found."""
        items = self.all()
        remaining = [item for item in items if item.resource_id != resource_id]
        if len(items) == len(remaining):
            return False
        self.storage.save_all(remaining)
        self.storage.log("DELETE", resource_id)
        return True

    def summary(self) -> dict[str, Any]:
        """Calculate total, category/status counts, and completion average."""
        items = self.all()
        categories = Counter(item.category for item in items)
        statuses = Counter(item.status for item in items)
        populated = [sum(bool(getattr(item, field)) for field in ("phone", "email", "website")) / 3 for item in items]
        return {
            "total": len(items),
            "by_category": dict(sorted(categories.items())),
            "by_status": dict(sorted(statuses.items())),
            "contact_completeness_percent": round(sum(populated) / len(populated) * 100, 1) if populated else 0.0,
        }
