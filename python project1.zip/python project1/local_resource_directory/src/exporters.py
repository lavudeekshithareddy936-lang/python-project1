"""Export summary reports in Markdown, CSV, and audit-log formats."""
import csv
from pathlib import Path
from .business_logic import ResourceService


def export_markdown(service: ResourceService, path: str | Path) -> Path:
    """Write a readable Markdown summary and category/status tables."""
    summary = service.summary()
    lines = ["# Local Resource Directory Report", "", f"- Total resources: **{summary['total']}**",
             f"- Contact completeness: **{summary['contact_completeness_percent']}%**", "",
             "## By category", "", "| Category | Count |", "|---|---:|"]
    lines += [f"| {name} | {count} |" for name, count in summary["by_category"].items()]
    lines += ["", "## By status", "", "| Status | Count |", "|---|---:|"]
    lines += [f"| {name} | {count} |" for name, count in summary["by_status"].items()]
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    service.storage.log("EXPORT_MARKDOWN", str(target))
    return target


def export_csv(service: ResourceService, path: str | Path) -> Path:
    """Export all resource records to a CSV report."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(service.all()[0].to_dict()) if service.all() else [])
        if service.all():
            writer.writeheader()
            writer.writerows([item.to_dict() for item in service.all()])
    service.storage.log("EXPORT_CSV", str(target))
    return target


def export_audit(service: ResourceService, path: str | Path) -> Path:
    """Copy the application audit log to an export location."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    source = service.storage.audit_path
    target.write_text(source.read_text(encoding="utf-8") if source.exists() else "", encoding="utf-8")
    service.storage.log("EXPORT_AUDIT", str(target))
    return target
