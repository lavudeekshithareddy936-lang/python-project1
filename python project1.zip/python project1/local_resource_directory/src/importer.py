"""Bulk CSV import with per-row validation and error reporting."""
import csv
from pathlib import Path
from typing import Any
from .business_logic import ResourceService
from .validators import validate_resource_data


def import_csv(path: str | Path, service: ResourceService) -> dict[str, Any]:
    """Import valid rows; retain row-specific errors without aborting the batch."""
    imported = 0
    errors: list[dict[str, str | int]] = []
    existing = {item.resource_id for item in service.all()}
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            return {"imported": 0, "errors": [{"row": 1, "error": "CSV has no header row."}]}
        for row_number, row in enumerate(reader, start=2):
            try:
                clean = validate_resource_data(row)
                if clean["resource_id"] in existing:
                    raise ValueError(f"Duplicate ID: {clean['resource_id']}")
                service.add(clean)
                existing.add(clean["resource_id"])
                imported += 1
            except (ValueError, TypeError, KeyError) as exc:
                errors.append({"row": row_number, "error": str(exc)})
    service.storage.log("CSV_IMPORT", f"Imported {imported}; rejected {len(errors)} rows from {Path(path).name}")
    return {"imported": imported, "errors": errors}
