"""Local Resource Directory application package."""
