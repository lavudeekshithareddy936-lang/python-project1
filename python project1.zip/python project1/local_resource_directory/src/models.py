"""Domain models for the Local Resource Directory."""
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class ServiceCategory(str, Enum):
    HEALTH = "Health"
    EDUCATION = "Education"
    FOOD = "Food"
    HOUSING = "Housing"
    EMPLOYMENT = "Employment"
    COMMUNITY = "Community"
    EMERGENCY = "Emergency"
    OTHER = "Other"


class ServiceStatus(str, Enum):
    ACTIVE = "Active"
    REVIEW = "Needs review"
    CLOSED = "Closed"


@dataclass(frozen=True)
class Resource:
    """A single community resource directory entry."""
    resource_id: str
    name: str
    category: str
    description: str
    address: str
    phone: str
    email: str
    website: str
    hours: str
    eligibility: str
    cost: str
    status: str = ServiceStatus.ACTIVE.value
    updated_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON/CSV-friendly mapping."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Resource":
        """Build a resource from a mapping, ignoring unknown keys."""
        fields = cls.__dataclass_fields__
        return cls(**{key: data[key] for key in fields if key in data})
