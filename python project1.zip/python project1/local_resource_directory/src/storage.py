"""Thread/process-safe persistence, atomic snapshots, SQLite mirror and recovery."""
import csv
import json
import os
import sqlite3
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

try:
    import fcntl  # POSIX
except ImportError:  # pragma: no cover - Windows
    fcntl = None
try:
    import msvcrt  # Windows
except ImportError:  # pragma: no cover - POSIX
    msvcrt = None

from .models import Resource
from .validators import validate_resource_data

CSV_FIELDS = list(Resource.__dataclass_fields__)


class ResourceStorage:
    """Persist resources with process locking and a rebuildable SQLite index."""

    def __init__(self, data_dir: str | Path = "data") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "resources.json"
        self.csv_path = self.data_dir / "resources.csv"
        self.db_path = self.data_dir / "resources.sqlite3"
        self.lock_path = self.data_dir / ".resources.lock"
        self.audit_path = self.data_dir / "audit_log.txt"
        self._thread_lock = threading.RLock()
        self._ensure_files()

    @contextmanager
    def _file_lock(self) -> Iterator[None]:
        """Acquire an OS-level advisory lock in addition to the thread lock."""
        with self._thread_lock:
            handle = open(self.lock_path, "a+b")
            try:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                elif msvcrt is not None:
                    handle.seek(0)
                    if handle.tell() == 0:
                        handle.write(b"0")
                        handle.flush()
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                yield
            finally:
                try:
                    if fcntl is not None:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                    elif msvcrt is not None:
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                finally:
                    handle.close()

    @staticmethod
    def _atomic_write(path: Path, text: str) -> None:
        """Write a complete replacement file and atomically swap it into place."""
        fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def log(self, action: str, detail: str = "") -> None:
        """Append a timestamped audit event."""
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        line = f"{stamp} | {action} | {detail.replace(chr(10), ' ')[:500]}\n"
        with self._file_lock():
            with self.audit_path.open("a", encoding="utf-8") as handle:
                handle.write(line)

    def _ensure_files(self) -> None:
        """Recover missing/corrupt JSON and initialize the SQLite index."""
        if not self.json_path.exists():
            self._atomic_write(self.json_path, "[]\n")
        try:
            self._read_json()
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = self.json_path.with_name(f"resources.corrupt_{stamp}.bak")
            try:
                os.replace(self.json_path, backup)
            except OSError:
                pass
            self._atomic_write(self.json_path, "[]\n")
            self.log("RECOVERY", f"Corrupt JSON archived as {backup.name}; initialized empty register")
        self._initialize_db()
        if not self.csv_path.exists():
            self.write_csv(self.list_resources())

    def _read_json(self) -> list[dict]:
        with self.json_path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, list) or any(not isinstance(row, dict) for row in value):
            raise json.JSONDecodeError("Expected a JSON array of objects", "", 0)
        return value

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=15)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("""CREATE TABLE IF NOT EXISTS resources (
            resource_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
            description TEXT NOT NULL, address TEXT NOT NULL, phone TEXT, email TEXT,
            website TEXT, hours TEXT, eligibility TEXT, cost TEXT, status TEXT,
            updated_at TEXT)""")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_resources_category ON resources(category)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_resources_name ON resources(name COLLATE NOCASE)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_resources_status ON resources(status)")
        return connection

    def _initialize_db(self) -> None:
        with self._connect() as connection:
            connection.commit()
        self._sync_db(self._read_json())

    def _sync_db(self, rows: list[dict]) -> None:
        with self._connect() as connection:
            connection.execute("DELETE FROM resources")
            connection.executemany(
                f"INSERT OR REPLACE INTO resources ({','.join(CSV_FIELDS)}) VALUES ({','.join('?' for _ in CSV_FIELDS)})",
                [[row.get(field, "") for field in CSV_FIELDS] for row in rows],
            )
            connection.commit()

    def list_resources(self) -> list[Resource]:
        """Return validated resources from the canonical JSON file."""
        with self._file_lock():
            rows = self._read_json()
            return [Resource.from_dict(validate_resource_data(row)) for row in rows]

    def save_all(self, resources: list[Resource]) -> None:
        """Atomically save JSON and CSV, then refresh SQLite."""
        rows = [resource.to_dict() for resource in resources]
        json_text = json.dumps(rows, ensure_ascii=False, indent=2) + "\n"
        csv_text = self._csv_text(rows)
        with self._file_lock():
            self._atomic_write(self.json_path, json_text)
            self._atomic_write(self.csv_path, csv_text)
            self._sync_db(rows)
        self.log("SAVE", f"Saved {len(rows)} resources")

    def _csv_text(self, rows: list[dict]) -> str:
        from io import StringIO
        output = StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue()

    def write_csv(self, resources: list[Resource]) -> None:
        """Atomically export a CSV snapshot."""
        self._atomic_write(self.csv_path, self._csv_text([r.to_dict() for r in resources]))

    def search_index(self, query: str = "", category: str = "", status: str = "") -> list[Resource]:
        """Search SQLite using indexed category/status and name/description filters."""
        sql = "SELECT " + ",".join(CSV_FIELDS) + " FROM resources WHERE 1=1"
        args: list[str] = []
        if category:
            sql += " AND category = ?"
            args.append(category)
        if status:
            sql += " AND status = ?"
            args.append(status)
        if query.strip():
            sql += " AND (name LIKE ? OR description LIKE ? OR address LIKE ?)"
            term = f"%{query.strip()}%"
            args.extend([term, term, term])
        sql += " ORDER BY name COLLATE NOCASE"
        with self._connect() as connection:
            rows = connection.execute(sql, args).fetchall()
        return [Resource.from_dict(dict(zip(CSV_FIELDS, row))) for row in rows]

    def index_info(self) -> list[str]:
        """Return created index names, useful for diagnostics and tests."""
        with self._connect() as connection:
            rows = connection.execute("PRAGMA index_list(resources)").fetchall()
        return [row[1] for row in rows]
