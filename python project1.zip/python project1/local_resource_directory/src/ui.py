"""ANSI terminal UI with guarded prompts and paginated record tables."""
import os
from typing import Callable
from .business_logic import ResourceService
from .models import Resource, ServiceCategory, ServiceStatus
from .validators import prompt_int, prompt_value, required_text, validate_resource_data


PAGE_SIZE = 8
RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"


def _color(text: str, code: str) -> str:
    return f"{code}{text}{RESET}" if os.getenv("NO_COLOR") is None else text


def _pause(input_fn: Callable[[str], str]) -> None:
    input_fn("\nPress Enter to continue...")


def _table(items: list[Resource], input_fn: Callable[[str], str] = input) -> None:
    """Render records in fixed-width pages with next/previous navigation."""
    if not items:
        print(_color("No matching resources found.", YELLOW))
        return
    page = 0
    pages = (len(items) + PAGE_SIZE - 1) // PAGE_SIZE
    while True:
        start = page * PAGE_SIZE
        current = items[start:start + PAGE_SIZE]
        print(f"\n{_color(f'Results {start + 1}-{start + len(current)} of {len(items)}', BOLD)}")
        print("-" * 98)
        print(f"{'ID':<12} {'NAME':<25} {'CATEGORY':<15} {'STATUS':<14} {'PHONE':<20}")
        print("-" * 98)
        for item in current:
            print(f"{item.resource_id[:11]:<12} {item.name[:24]:<25} {item.category[:14]:<15} "
                  f"{item.status[:13]:<14} {item.phone[:19]:<20}")
        print("-" * 98)
        if pages == 1:
            break
        choice = input_fn(f"Page {page + 1}/{pages} [N]ext / [P]revious / [Q]uit: ").strip().lower()
        if choice == "n" and page + 1 < pages:
            page += 1
        elif choice == "p" and page > 0:
            page -= 1
        elif choice in ("q", ""):
            break
        else:
            print("Choose N, P, or Q.")


def run_cli(service: ResourceService, input_fn: Callable[[str], str] = input) -> None:
    """Run the menu-driven terminal application."""
    while True:
        print("\n" + _color("LOCAL RESOURCE DIRECTORY", CYAN + BOLD))
        print("1. List all resources  2. Search/filter  3. Add resource")
        print("4. Summary metrics     5. Export reports  6. Quit")
        try:
            choice = input_fn("Select 1–6: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            return
        try:
            if choice == "1":
                _table(service.all(), input_fn)
            elif choice == "2":
                query = input_fn("Keyword (blank for all): ").strip()
                category = input_fn("Category (blank for any): ").strip()
                status = input_fn("Status (blank for any): ").strip()
                _table(service.search(query, category, status), input_fn)
            elif choice == "3":
                data = {}
                fields = [
                    ("resource_id", "ID: "), ("name", "Name: "), ("category", "Category: "),
                    ("description", "Description: "), ("address", "Address: "), ("phone", "Phone: "),
                    ("email", "Email: "), ("website", "Website: "), ("hours", "Hours: "),
                    ("eligibility", "Eligibility: "), ("cost", "Cost: "), ("status", "Status [Active]: ")
                ]
                for key, prompt in fields:
                    data[key] = input_fn(prompt).strip()
                data["status"] = data["status"] or "Active"
                service.add(data)
                print(_color("Resource added.", GREEN))
            elif choice == "4":
                print(service.summary())
            elif choice == "5":
                from .exporters import export_csv, export_markdown, export_audit
                export_markdown(service, "reports/summary.md")
                export_csv(service, "reports/resources.csv")
                export_audit(service, "reports/audit_log.txt")
                print(_color("Reports written to reports/.", GREEN))
            elif choice == "6":
                print("Goodbye.")
                return
            else:
                print(_color("Please choose a menu option from 1 to 6.", YELLOW))
        except (ValueError, OSError) as exc:
            print(_color(f"Action could not be completed: {exc}", YELLOW))
